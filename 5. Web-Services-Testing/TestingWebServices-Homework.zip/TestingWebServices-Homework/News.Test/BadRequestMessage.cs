﻿namespace News.Test
{
    public class BadRequestMessage
    {
        public string Message { get; set; }
    }
}
