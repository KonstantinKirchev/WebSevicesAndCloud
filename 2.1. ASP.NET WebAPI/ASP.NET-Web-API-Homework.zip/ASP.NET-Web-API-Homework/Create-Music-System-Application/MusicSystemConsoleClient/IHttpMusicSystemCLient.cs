﻿using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Policy;
using System.Xml;

namespace MusicSystemConsoleClient
{
    public interface IHttpMusicSystemCLient
    {
        IEnumerable<T> All<T>()
        {
            
        }
    }
}
