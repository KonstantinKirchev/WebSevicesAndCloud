# Messages-REST-Service
Sample RESTFul Web Services project, part of the "Web Services and Cloud" course at the Software University: https://softuni.bg/trainings/22/Web-Services-and-Cloud-Apr-2015
 - Based on ASP.NET Web API 2.2
 - Uses Repository + Unit of Work Patterns
 - Integration Tests based on Microsoft.Owin.Testing

See the project assignment here: https://github.com/nakov/Messages-REST-Service/blob/master/Web-Services-and-Cloud-Sample-Exam-Messages-April-2015.docx

