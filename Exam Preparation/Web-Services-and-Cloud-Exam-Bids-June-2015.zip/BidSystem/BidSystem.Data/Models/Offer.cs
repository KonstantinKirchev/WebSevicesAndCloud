﻿namespace BidSystem.Data.Models
{
    public class Offer
    {
        public int Id { get; set; }

        // TODO
    }
}
