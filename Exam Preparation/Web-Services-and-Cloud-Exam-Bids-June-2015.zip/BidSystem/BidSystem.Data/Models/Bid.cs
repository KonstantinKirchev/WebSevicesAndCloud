﻿namespace BidSystem.Data.Models
{
    public class Bid
    {
        public int Id { get; set; }
        
        // TODO
    }
}
