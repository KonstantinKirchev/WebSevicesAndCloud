﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MessagesWebApp.Models
{
	[MetadataType(typeof(MessageMetadata))]
	public partial class Message
	{
	}

	public class MessageMetadata
	{
		[Required]
		public string MsgText { get; set; }

		[Required]
		[DisplayFormat(DataFormatString="{0:dd-MMM-yyyy h:mm:ss}", ApplyFormatInEditMode=true)]
		public DateTime MsgDate { get; set; }
	}
}