CREATE TABLE [dbo].[Messages](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[MsgText] [nvarchar](max) NOT NULL,
	[MsgDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Messages] PRIMARY KEY CLUSTERED ([MessageId] ASC)
)
GO

SET IDENTITY_INSERT [dbo].[Messages] ON
INSERT [dbo].[Messages] ([MessageId], [MsgText], [MsgDate]) VALUES (1, N'Hello Web Services & Cloud Course!', CAST(0x0000A0CC0019BEA0 AS DateTime))
INSERT [dbo].[Messages] ([MessageId], [MsgText], [MsgDate]) VALUES (2, N'Welcome to SoftUni.', CAST(0x0000A0BF0070A904 AS DateTime))
INSERT [dbo].[Messages] ([MessageId], [MsgText], [MsgDate]) VALUES (12, N'AppHarbor - public cloud for .NET developers', CAST(0x0000A0DB0019BEA0 AS DateTime))
INSERT [dbo].[Messages] ([MessageId], [MsgText], [MsgDate]) VALUES (22, N'Azure - the official Microsoft .NET cloud!', CAST(0x0000A0D50138FD26 AS DateTime))
SET IDENTITY_INSERT [dbo].[Messages] OFF

ALTER TABLE [dbo].[Messages] 
ADD CONSTRAINT [DF_Messages_MsgDate] DEFAULT (getdate()) FOR [MsgDate]
GO
