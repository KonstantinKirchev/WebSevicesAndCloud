package cloudchat.rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import cloudchat.data.ChatMessage;

@Path("/chat")
public class ChatService {
	
	private static List<ChatMessage> messages;
	
	static {
		messages = new ArrayList<ChatMessage>();
		ChatMessage firstMsg = new ChatMessage();
		firstMsg.setId(1);
		firstMsg.setDate(new Date());
		firstMsg.setAuthor("Nakov");
		firstMsg.setText("Hi all.");
		messages.add(firstMsg);
		
		ChatMessage secondMsg = new ChatMessage();
		secondMsg.setId(2);
		secondMsg.setDate(new Date());
		secondMsg.setAuthor("Peter");
		secondMsg.setText("Hi Nakov");
		messages.add(secondMsg);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/messages")
	public List<ChatMessage> getChatMessages() {
		return messages;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path("/messages/send")
	public void sendChatMessage(
			@FormParam("author") String author,
			@FormParam("msgText") String msgText) {
		ChatMessage msg = new ChatMessage();
		msg.setId(0);
		msg.setAuthor(author);
		msg.setText(msgText);
		msg.setDate(new Date());
		messages.add(msg);
	}
}
