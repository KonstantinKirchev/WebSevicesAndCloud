$(document).ready(initializeChat);

function initializeChat() {
    serviceUrl = "/services/chat";
	window.setInterval(updateChatMessages, 500);
	$('#buttonSend').click(sendButtonClick);
}

function updateChatMessages() {
    $.ajax({
        url: serviceUrl + "/messages",
        dataType: "json",
        success: showChatMessages,
        error: ajaxCallError
    });
}

function showChatMessages(messages) {
	var chatHtml = "";
	for (var i in messages.messages) {
		var msg = messages.messages[i];
		var author = htmlEncode(msg.author);
		var text = htmlEncode(msg.text);
		var date = new Date(msg.date);
		var time = formatDateAsHoursMinutesSeconds(date);
		chatHtml = chatHtml + 
			"<div class='chatMsg'>" +
			"<span class='msgAuthor'>" + author + ":</span>" +
			"<span class='msgText'>" + text + "</span>" +
			"<span class='msgTime'>(" + time + ")</span>" +
			"</div>";
	}
	$("#chatMessages").html(chatHtml);
	scrollToBottom($("#chatMessages"));
}

function sendButtonClick() {
	var userName = $("#userName").val();
	var msgToSend = $("#msgToSend").val();
    var chatMsg = { "author": userName, "msgText": msgToSend };
    $.ajax({
        url: serviceUrl + "/messages/send",
        type: "POST",
        data: chatMsg,
        success: processSentChatMessage,
        error: ajaxCallError
    });
}

function processSentChatMessage(){
	$("#msgToSend").val("");
}

function ajaxCallError(err) {
	$("#errors").fadeIn("slow");
	var time = formatDateAsHoursMinutesSeconds(new Date());
	var errorMsg = "(" + time + ") error: " + err.status;
	$("#errorLog").val(
        "\n" + $("#errorLog").val() + "\n" + errorMsg
    );	
	scrollToBottom($("#errorLog"));
}

function htmlEncode(textToEncode) {
	var htmlEncodedText = $('<div/>').text(textToEncode).html();
	return htmlEncodedText;
}

function formatDateAsHoursMinutesSeconds(date) {
	var hours = date.getHours();
	var minutes = date.getMinutes();
	if (minutes < 10) {
		minutes = "0" + minutes;
	}
	var seconds = date.getSeconds();
	if (seconds < 10) {
		seconds = "0" + seconds;
	}
	var time = hours + ":" + minutes + ":" + seconds;
	return time;
}

function scrollToBottom(element) {
	element.animate({
	    scrollTop:element[0].scrollHeight
	}, 100);	
}
