﻿namespace Battleships.WebServices.Infrastructure
{
    public interface IUserIdProvider
    {
        string GetUserId();
    }
}