﻿namespace Battleships.WebServices.Models
{
    public class JoinGameBindingModel
    {
        public string GameId { get; set; }
    }
}