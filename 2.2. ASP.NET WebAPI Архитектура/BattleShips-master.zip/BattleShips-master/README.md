# Battleships Game
ASP.NET Web API web services created for the Web Services and Cloud course @ SoftUni https://softuni.bg/courses/web-services-and-cloud/